import React from "react";
import HomePage from "./components/Welcome";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import UserPage from "./components/UserPage";
import EngineerPage from "./components/EngineerPage";


const App: React.FC = () => {
   return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/user" element={<UserPage/>} />
        <Route path="/engineer" element={<EngineerPage/>} />
      </Routes>
    </Router>
  );
}

export default App;
