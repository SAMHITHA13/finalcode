import React, { useState } from "react";
import { MenuOutlined } from "@ant-design/icons";
import { Button, Card, List, Typography, Layout, Space } from "antd";
import "./EngineerPage.css";
import axios from "axios";
import type { EngineerType, ServiceType } from "../types/types";
import { useLocation } from "react-router-dom";

const { Header, Sider, Content } = Layout;
const { Title } = Typography;

interface TicketType {
  id: string;
  service: string;
  date: string;
  location: string;
  status: string;
}

interface LocationState {
  result: EngineerType;
}


const EngineerPage: React.FC = () => {
  const [selectedMenu, setSelectedMenu] = useState("open");
  const [openRequests, setOpenRequests] = useState<ServiceType[]>([]);

    const location = useLocation();
  const state = location.state as LocationState | null;

  const user = state?.result;

  console.log("User", user);


    const fetchOpenRequests = async () => {
    try {
       const res = await axios.post("http://127.0.0.1:5000/engineer_requests", {
  engineer_id: user?.engineer_id,
});

      setOpenRequests(res.data.assigned_requests); // expecting array of ticket objects
    } catch (error) {
      console.error("Error fetching open requests:", error);
    }
  };

  const handleOpenRequestsClick = () => {
    setSelectedMenu("open");
    fetchOpenRequests(); // Call API when button is clicked
  };

  // Dummy data for open requests
//   const openRequests: TicketType[] = [
//     {
//       id: "REQ1001",
//       service: "Electrician",
//       date: "2025-12-05",
//       location: "Hyderabad",
//       status: "Open",
//     },
//     {
//       id: "REQ1002",
//       service: "Cleaning",
//       date: "2025-12-05",
//       location: "Bangalore",
//       status: "Open",
//     },
//   ];

  // Dummy data for past requests
  const pastRequests: ServiceType[] = [
    {
       request_id:"",
                user_id: "",
                requested_service: "",
                price: "",
                location: "",
                priority: "",
                required_skill: "",
                estimated_duration_minutes: "",
                requested_datetime: "",
                scheduled_datetime: "",
                status: "",
                assigned_engineer_id: "",
                crm_ticket_id: "",
                created_at: "",
    },
  ];

  const renderContent = () => {
    const listData = selectedMenu === "open" ? openRequests : pastRequests;

    return (
      <div className="eng-content-wrapper">
        <Title level={3} className="eng-section-title">
          {selectedMenu === "open" ? "Open Requests" : "Past Requests"}
        </Title>

        <List
          dataSource={listData}
          renderItem={(item) => (
            <Card className="eng-request-card">
              <p><strong>ID:</strong> {item.assigned_engineer_id}</p>
              <p><strong>Service:</strong> {item.requested_service}</p>
              <p><strong>Date:</strong> {item.requested_datetime}</p>
              <p><strong>Location:</strong> {item.location}</p>
              <p><strong>Status:</strong> {item.status}</p>

              {/* Buttons only for Open Requests */}
              {selectedMenu === "open" && (
                <Space className="eng-buttons-row">
                  <Button type="primary" className="eng-getDirections-btn">
                    Get Directions
                  </Button>

                  <Button type="primary" className="eng-startJob-btn">
                    Start Job
                  </Button>

                  <Button type="primary" className="eng-jobDone-btn">
                    Job Done
                  </Button>
                </Space>
              )}
            </Card>
          )}
        />
      </div>
    );
  };

  return (
    <Layout className="engineer-layout">
      {/* Header */}
      <Header className="engineer-header">
        <MenuOutlined className="hamburger-icon" />
        <Title level={2} className="header-title">
          Welcome {user?.name}
        </Title>
      </Header>

      <Layout>
        {/* Left Sidebar */}
        <Sider width={200} className="engineer-sider">
          <div className="engmenu-buttons">
            <Button
              block
              className={`engmenu-btn ${selectedMenu === "open" ? "active" : ""}`}
              onClick={handleOpenRequestsClick}
            >
              Open Requests
            </Button>

            <Button
              block
              className={`engmenu-btn ${selectedMenu === "past" ? "active" : ""}`}
              onClick={() => setSelectedMenu("past")}
            >
              Past Requests
            </Button>
          </div>
        </Sider>

        {/* Main Content */}
        <Content className="engineer-content">{renderContent()}</Content>
      </Layout>
    </Layout>
  );
};

export default EngineerPage;
