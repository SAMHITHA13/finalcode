// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import { Layout, List, Tabs, Input, Button } from "antd";

// const { Sider, Content } = Layout;
// const { TabPane } = Tabs;

// // ---------- Types --------------
// interface ReportType {
//   instanceId?: string;
//   cpu?: string;
//   memory?: string;
//   disk?: string;
//   status?: string;
// }

// interface ApiResponse {
//   summary: string[];
//   report: ReportType;
//   chat_response?: string;
// }

// interface InstancesResponse {
//   instances: string[];
// }
// // --------------------------------

// const InstanceUI: React.FC = () => {
//   const [instances, setInstances] = useState<string[]>([]);
//   const [selectedInstance, setSelectedInstance] = useState<string>("");
//   const [summary, setSummary] = useState<string[]>([]);
//   const [report, setReport] = useState<ReportType>({});
//   const [chatInput, setChatInput] = useState<string>("");
//   const [chatResponse, setChatResponse] = useState<string>("");

//   // Load instance IDs on startup
//   useEffect(() => {
//     const loadInstances = async () => {
//       const res = await axios.get<InstancesResponse>(
//         "http://127.0.0.1:5000/api/instances"
//       );
//       setInstances(res.data.instances);
//     };
//     loadInstances();
//   }, []);

//   // Call Flask AI
//   const fetchInstanceData = async (instanceId: string, prompt?: string) => {
//     const response = await axios.post<ApiResponse>(
//       "http://127.0.0.1:5000/api/process",
//       {
//         instanceId,
//         prompt,
//       }
//     );

//     const data = response.data;
//     setSummary(data.summary);
//     setReport(data.report);
//     if (prompt) setChatResponse(data.chat_response || "");
//   };

//   const onInstanceClick = (id: string) => {
//     setSelectedInstance(id);
//     fetchInstanceData(id);
//   };

//   const sendChat = () => {
//     if (selectedInstance) {
//       fetchInstanceData(selectedInstance, chatInput);
//     }
//   };

//   return (
//     <Layout style={{ height: "100vh" }}>
//       {/* LEFT SIDEBAR */}
//       <Sider width={250} style={{ background: "#f5f5f5", overflowY: "auto" }}>
//         <h3 style={{ padding: 10 }}>Instances</h3>

//         <List
//           dataSource={instances}
//           renderItem={(item) => (
//             <List.Item
//               onClick={() => onInstanceClick(item)}
//               style={{ cursor: "pointer" }}
//             >
//               {item}
//             </List.Item>
//           )}
//         />
//       </Sider>

//       {/* RIGHT SIDE CONTENT */}
//       <Content style={{ padding: 20 }}>
//         <Tabs defaultActiveKey="1">
//           <TabPane tab="Summary" key="1">
//             <ul>
//               {summary.map((s, idx) => (
//                 <li key={idx}>{s}</li>
//               ))}
//             </ul>
//           </TabPane>

//           <TabPane tab="Report" key="2">
//             <pre>{JSON.stringify(report, null, 2)}</pre>
//           </TabPane>

//           <TabPane tab="Chatbot" key="3">
//             <Input
//               placeholder="Enter your prompt..."
//               value={chatInput}
//               onChange={(e) => setChatInput(e.target.value)}
//             />
//             <Button type="primary" onClick={sendChat} style={{ marginTop: 10 }}>
//               Send
//             </Button>

//             <div style={{ marginTop: 20 }}>
//               <h4>Response:</h4>
//               <p>{chatResponse}</p>
//             </div>
//           </TabPane>
//         </Tabs>
//       </Content>
//     </Layout>
//   );
// };

// export default InstanceUI;


import React, { useEffect, useState } from "react";
import axios from "axios";
import { Layout, Menu, Tabs, Input, Button, Card } from "antd";

const { Sider, Content } = Layout;

// ---------- Types --------------
interface ReportType {
  instanceId?: string;
  cpu?: string;
  memory?: string;
  disk?: string;
  status?: string;
}

interface ApiResponse {
  summary: string[];
  report: ReportType;
  chat_response?: string;
}

interface InstancesResponse {
  instances: string[];
}
// --------------------------------

const InstanceUI: React.FC = () => {
  const [instances, setInstances] = useState<string[]>([]);
  const [selectedInstance, setSelectedInstance] = useState<string>("");
  const [summary, setSummary] = useState<string[]>([]);
  const [report, setReport] = useState<ReportType>({});
  const [chatInput, setChatInput] = useState<string>("");
  const [chatResponse, setChatResponse] = useState<string>("");

  // Load instance IDs on startup
  useEffect(() => {
    const loadInstances = async () => {
      const res = await axios.get<InstancesResponse>(
        "http://127.0.0.1:5000/api/instances"
      );
      setInstances(res.data.instances);
    };
    loadInstances();
  }, []);

  // Call Flask AI
  const fetchInstanceData = async (instanceId: string, prompt?: string) => {
    const response = await axios.post<ApiResponse>(
      "http://127.0.0.1:5000/api/process",
      {
        instanceId,
        prompt,
      }
    );

    setSummary(response.data.summary);
    setReport(response.data.report);
    if (prompt) setChatResponse(response.data.chat_response || "");
  };

  const onInstanceClick = (key: string) => {
    setSelectedInstance(key);
    fetchInstanceData(key);
  };

  const sendChat = () => {
    if (selectedInstance) {
      fetchInstanceData(selectedInstance, chatInput);
    }
  };

  return (
    <Layout style={{ height: "100vh", background: "#fff" }}>
      {/* LEFT SIDEBAR */}
      <Sider width={260} style={{ background: "#f9f9f9", borderRight: "1px solid #ddd" }}>
        <h3 style={{ padding: "15px", margin: 0 }}>Instances</h3>

        <Menu
          mode="inline"
          selectedKeys={[selectedInstance]}
          onClick={(info) => onInstanceClick(info.key)}
          items={instances.map((inst) => ({
            key: inst,
            label: inst,
          }))}
          style={{ height: "calc(100vh - 50px)", overflowY: "auto" }}
        />
      </Sider>

      {/* RIGHT SIDE CONTENT */}
      <Content style={{ padding: 20 }}>
        <Card style={{ minHeight: "95vh" }}>
          <Tabs
            defaultActiveKey="1"
            items={[
              {
                key: "1",
                label: "Summary",
                children: (
                  <ul>
                    {summary.map((s, idx) => (
                      <li key={idx}>{s}</li>
                    ))}
                  </ul>
                ),
              },
              {
                key: "2",
                label: "Report",
                children: (
                  <pre style={{ background: "#f0f0f0", padding: 15, borderRadius: 5 }}>
                    {JSON.stringify(report, null, 2)}
                  </pre>
                ),
              },
              {
                key: "3",
                label: "Chatbot",
                children: (
                  <>
                    <Input
                      placeholder="Enter your prompt..."
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                    />
                    <Button
                      type="primary"
                      onClick={sendChat}
                      style={{ marginTop: 10 }}
                    >
                      Send
                    </Button>

                    <div style={{ marginTop: 20 }}>
                      <h4>Response:</h4>
                      <Card style={{ background: "#fafafa" }}>{chatResponse}</Card>
                    </div>
                  </>
                ),
              },
            ]}
          />
        </Card>
      </Content>
    </Layout>
  );
};

export default InstanceUI;

