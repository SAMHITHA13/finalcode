// import React from "react";
// import { Button, Card, Row, Col } from "antd";
// import "./Welcome.css";

// const services = [
//   "Cleaning",
//   "Electrician",
//   "Pest Control",
//   "Saloon",
//   "Plumber",
//   "Painting",
// ];

// const HomePage: React.FC = () => {
//   return (
//     <div className="main-container">

//       {/* ---------- TOP BAR ---------- */}
//       <div className="top-bar">
//         <div className="logo-container">
//           <img src="/logo.png" alt="Logo" className="logo" />
//         </div>

//         <div className="menu-buttons">
//           <Button type="text" className="nav-btn active">Home</Button>
//           <Button type="text" className="nav-btn">Login as User</Button>
//           <Button type="text" className="nav-btn">Login as Agent</Button>
//         </div>
//       </div>

//       {/* ---------- TITLE BAR ---------- */}
//       <div className="title-bar">
//         <h1>Service Buzz</h1>
//       </div>

//       {/* ---------- DESCRIPTION ---------- */}
//       <p className="description">
//         Designed to serve all the services in the best way possible aiming customer satisfaction.
//       </p>

//       {/* ---------- SERVICE CARDS ---------- */}
//       <div className="cards-container">
//         <Row gutter={[20, 20]}>
//           {services.map((service) => (
//             <Col xs={24} sm={12} md={8} lg={8} key={service}>
//               <Card className="service-card" hoverable>
//                 <h3>{service}</h3>
//               </Card>
//             </Col>
//           ))}
//         </Row>
//       </div>

//       {/* ---------- CHAT BUTTON ---------- */}
//       <div className="chat-button-container">
//         <Button type="primary" size="large" className="chat-button">
//           Chat With Us
//         </Button>
//       </div>

//     </div>
//   );
// };

// export default HomePage;


import React, { useState } from "react";
import { Button, Card, Row, Col, Modal, Input } from "antd";
import "./Welcome.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import type { EngineerType, UserType } from "../types/types";


const services = [
  "Cleaning",
  "Electrician",
  "Pest Control",
  "Saloon",
  "Plumber",
  "Painting",
];

const HomePage: React.FC = () => {
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");

  const [isEngineerModalOpen, setIsEngineerModalOpen] = useState(false);
  const [engineerEmail, setEngineerEmail] = useState<string>("");
  const [engineerPassword, setEngineerPassword] = useState<string>("");
  const [userDetails, setUserDetails]=useState<UserType>();
  const [engineerDetails, setEngineerDetails]=useState<EngineerType>();
  const navigate = useNavigate();

  const sendRequest = async () => {
    try {
      const res = await axios.post(`http://127.0.0.1:5000/login`, {
        email,
        password,
      });
      if (res.data.success) {
        //alert("Successfull")
        const result: UserType=res.data.user;
        setUserDetails(result);
        navigate("/user",{
          state: {
            result,   // passing the whole object
          },
        });
        return;
      };
    } catch (err: any) {
      if (err.response && err.response.data && err.response.data.error) {
        alert(err.response.data.error);
      } else {
        console.error(err);
        alert("Something went wrong");
      }
    }
  };


  const sendEngineerRequest = async () => {
    try {
      const res = await axios.post(`http://127.0.0.1:5000/engineer_login`, {
        engineerEmail,
        engineerPassword,
      });
      if (res.data.success) {
        //alert("Successfull")
        const result: EngineerType=res.data.engineer;
        setEngineerDetails(result);
        navigate("/engineer",{
          state: {
            result,   // passing the whole object
          },
        });
        return;
      };
    } catch (err: any) {
      if (err.response && err.response.data && err.response.data.error) {
        alert(err.response.data.error);
      } else {
        console.error(err);
        alert("Something went wrong");
      }
    }
  };

  const handleUserLoginOpen = () => {
    setIsUserModalOpen(true);
  };

  const handleUserLoginClose = () => {
    setIsUserModalOpen(false);
    setEmail("");
    setPassword("");
  };

  const handleVerifyLogin = () => {
    console.log("Email:", email);
    console.log("Password:", password);
    sendRequest();
  };

  const handleEngineerLoginOpen=()=>{
    setIsEngineerModalOpen(true);
  }

  const handleEngineerLoginClose=()=>{
    setIsEngineerModalOpen(false);

  }

  const handleEngineerVerifyLogin=()=>{
    console.log("Email:", engineerEmail);
    console.log("Password:", engineerPassword);
    sendEngineerRequest();
  }

  

  return (
    <div className="main-container">

      {/* ---------- TOP BAR ---------- */}
      <div className="top-bar">
        <div className="logo-container">
          <img src="/logo.png" alt="Logo" className="logo" />
        </div>

        <div className="menu-buttons">
          <Button type="text" className="nav-btn active">Home</Button>

          {/* Show modal when clicked */}
          <Button type="text" className="nav-btn" onClick={handleUserLoginOpen}>
            Login as User
          </Button>

          <Button type="text" className="nav-btn" onClick={handleEngineerLoginOpen}>Login as Engineer </Button>
        </div>
      </div>

      {/* ---------- TITLE BAR ---------- */}
      <div className="title-bar">
        <h1>Service Buzz</h1>
      </div>

      {/* ---------- DESCRIPTION ---------- */}
      <p className="description">
        Designed to serve all the services in the best way possible.
      </p>

      {/* ---------- SERVICE CARDS ---------- */}
      <div className="cards-container">
        <Row gutter={[20, 20]}>
          {services.map((service) => (
            <Col xs={24} sm={12} md={8} lg={8} key={service}>
              <Card className="service-card" hoverable>
                <h3>{service}</h3>
              </Card>
            </Col>
          ))}
        </Row>
      </div>

      {/* ---------- CHAT BUTTON ---------- */}
      <div className="chat-button-container">
        <Button type="primary" size="large" className="chat-button">
          Chat With Us
        </Button>
      </div>

      {/* ---------- USER LOGIN MODAL ---------- */}
      <Modal
        title="User Login"
        open={isUserModalOpen}
        onCancel={handleUserLoginClose}
        footer={null}
        centered
      >
        <div className="modal-input-container">
          <label>Email</label>
          <Input
            placeholder="Enter email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <label>Password</label>
          <Input.Password
            placeholder="Enter password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <Button
            type="primary"
            className="verify-login-btn"
            onClick={handleVerifyLogin}
          >
            Verify & Login
          </Button>
        </div>
      </Modal>



       {/* ---------- AGENT LOGIN MODAL ---------- */}
      <Modal
        title="Engineer Login"
        open={isEngineerModalOpen}
        onCancel={handleEngineerLoginClose}
        footer={null}
        centered
      >
        <div className="modal-input-container">
          <label>Email</label>
          <Input
            placeholder="Enter email"
            value={engineerEmail}
            onChange={(e) => setEngineerEmail(e.target.value)}
          />

          <label>Password</label>
          <Input.Password
            placeholder="Enter password"
            value={engineerPassword}
            onChange={(e) => setEngineerPassword(e.target.value)}
          />

          <Button
            type="primary"
            className="verify-login-btn"
            onClick={handleEngineerVerifyLogin}
          >
            Verify & Login
          </Button>
        </div>
      </Modal>

    </div>
  );
};

export default HomePage;

