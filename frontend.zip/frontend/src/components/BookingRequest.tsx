// src/components/BookingRequest.tsx
import React, { useState } from "react";
import { Modal, DatePicker, Select, Button, message } from "antd";
import "./BookingRequest.css";
import type { UserType } from "../types/types";
import axios from "axios";

interface BookingRequestProps {
  open: boolean;
  userDetails: UserType;
  serviceName: string;
  onClose: () => void;
}

const BookingRequest: React.FC<BookingRequestProps> = ({
  open,
  serviceName,
  userDetails,
  onClose,
}) => {
  // ----------------------
  // STATE VARIABLES
  // ----------------------
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [timeSlot, setTimeSlot] = useState<string>("");
  const [location, setLocation] = useState<string>("");
  const [priority, setPriority] = useState<string>("");

  console.log("User Details: ", userDetails);

  // ----------------------
  // API CALL TO FLASK
  // ----------------------
  const sendBookingRequest = async () => {
    if (!selectedDate || !timeSlot || !location) {
      message.error("Please select all fields!");
      return;
    }

    const payload = {
      requested_service:serviceName,
      date: selectedDate,
      time:timeSlot,
      location:location,
      priority: priority,
      user_id: userDetails?.user_id, // adjust based on UserType
    };


    console.log("Payload", payload);

    try {
      const res = await axios.post("http://127.0.0.1:5000/book_request", payload);
      console.log("Response:", res.data.request_id);
      message.success("Booking request sent successfully!");
      onClose();
    } catch (error) {
      console.error("Error:", error);
      message.error("Failed to submit booking request!");
    }
  };

  return (
    <Modal open={open} onCancel={onClose} footer={null}>
      <h2 className="booking-title">{serviceName} Service Request</h2>

      {/* DATE */}
      <div className="booking-field">
        <label>Date</label>
        <DatePicker
          style={{ width: "100%" }}
          onChange={(date, dateString) => setSelectedDate(dateString)}
        />
      </div>

      {/* TIME SLOT */}
      <div className="booking-field">
        <label>Time Slot</label>
        <Select
          placeholder="Select time slot"
          style={{ width: "100%" }}
          onChange={(value) => setTimeSlot(value)}
          options={[
            { value: "9:00AM", label: "9:00AM" },
            { value: "10:00AM", label: "10:00AM" },
            { value: "11:00AM", label: "11:00AM" },
            { value: "12:00PM", label: "12:00PM" },
            { value: "1:00PM", label: "1:00PM" },
            { value: "2:00PM", label: "2:00PM" },
            { value: "3:00PM", label: "3:00PM" },
            { value: "4:00PM", label: "4:00PM" },
            { value: "5:00PM", label: "5:00PM" },
            { value: "6:00PM", label: "6:00PM" },
            { value: "7:00PM", label: "7:00PM" },
          ]}
        />
      </div>

      {/* LOCATION */}
      <div className="booking-field">
        <label>Location</label>
        <Select
          placeholder="Select location"
          style={{ width: "100%" }}
          onChange={(value) => setLocation(value)}
          options={[
            { value: "Tarnaka", label: "Tarnaka" },
            { value: "Panjagutta", label: "Panjagutta" },
            { value: "Secunderabad", label: "Secunderabad" },
            { value: "Kukatpally", label: "Kukatpally" },
          ]}
        />
      </div>

      {/* PRIORITY */}
      <div className="booking-field">
        <label>Priority</label>
        <Select
          placeholder="Select priority"
          style={{ width: "100%" }}
          onChange={(value) => setPriority(value)}
          options={[
            { value: "Urgent", label: "Urgent" },
            { value: "High", label: "High" },
            { value: "Medium", label: "Medium" },
            { value: "Low", label: "Low" },
          ]}
        />
      </div>

      <Button
        type="primary"
        block
        style={{ marginTop: "1em" }}
        onClick={sendBookingRequest}
      >
        Submit
      </Button>
    </Modal>
  );
};

export default BookingRequest;
