import React, { useState } from "react";
import { Input, Card, Button, Drawer } from "antd";
import { MenuOutlined } from "@ant-design/icons";
import "./UserPage.css";
import { useLocation } from "react-router-dom";
import type { UserType } from "../types/types";
import BookingRequest from "./BookingRequest";

const { Search } = Input;

interface LocationState {
  result: UserType;
}


const services = [
  {
    name: "Electrician",
    desc: "Professional electrical repairs, installations and inspections."
  },
  {
    name: "Cleaning",
    desc: "Home & office cleaning with expert staff and quality service."
  },
  {
    name: "Pest Control",
    desc: "Safe and effective pest treatment for homes and workplaces."
  },
  {
    name: "Painting",
    desc: "Interior & exterior painting by trained professionals."
  },
  {
    name: "Plumber",
    desc: "Leak fixes, installations, and plumbing maintenance."
  },
  {
    name: "Saloon",
    desc: "Grooming and styling services at your doorstep."
  },
];

const UserPage: React.FC = () => {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [searchText, setSearchText] = useState("");
  const location = useLocation();
  const state = location.state as LocationState | null;

  const user = state?.result;

  const [bookingOpen, setBookingOpen] = useState(false);
  const [selectedService, setSelectedService] = useState("");

//   const filteredServices = services.filter((s) =>
//     s.name.toLowerCase().includes(searchText.toLowerCase())
//   );

  const handleBook = (serviceName: string) => {
    setSelectedService(serviceName);
    setBookingOpen(true);
  };

  return (
    <div className="user-page-container">
      
      {/* ------------ HEADER ------------- */}
      <div className="user-header">
        <MenuOutlined className="menu-icon" onClick={() => setDrawerOpen(true)} />
        <h1>Welcome {user?.user_name}</h1>
      </div>

      {/* ------------ LEFT DRAWER MENU ------------- */}
      <Drawer
        title="Menu"
        placement="left"
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
      >
        <div className="drawer-menu">
          <p className="drawer-item">Profile</p>
          <p className="drawer-item">Past Bookings</p>
          <p className="drawer-item">Booked Requests</p>
          <p className="drawer-item">Help</p>
        </div>
      </Drawer>

      {/* ------------ RIGHT PAGE CONTENT ------------- */}
      <div className="content-section">

        {/* SEARCH BAR */}
        <div className="search-container">
          <Search
            placeholder="Search services"
            allowClear
            enterButton
            size="large"
            onChange={(e) => setSearchText(e.target.value.toLowerCase())}
          />
        </div>

        {/* SERVICE CARDS */}
        {/* <div className="services-grid">
          {services.map((srv) => (
            <Card key={srv.name} className="service-card" hoverable>
              <h3>{srv.name}</h3>
              <p className="service-desc">{srv.desc}</p>
              <Button type="primary" className="book-btn">
                Book Request
              </Button>
            </Card>
          ))}
        </div> */}

    <div className="services-grid">
    {services.map((srv) => {
        const isMatch = srv.name.toLowerCase().includes(searchText);

        return (
        <Card
            key={srv.name}
            className={`service-card ${isMatch && searchText ? "highlight-card" : ""}`}
            hoverable
        >
            <h3>{srv.name}</h3>
            <p className="service-desc">{srv.desc}</p>
            <Button type="primary" className="book-btn" onClick={() => handleBook(srv.name)}>
            Book Request
            </Button>
        </Card>
        );
    })}
    </div>


      </div>

     {user &&  <BookingRequest
        open={bookingOpen}
        serviceName={selectedService}
        userDetails={user}
        onClose={() => setBookingOpen(false)}
      />
     }


    </div>
  );
};

export default UserPage;
