export interface UserType {
  email: string;
  phone: string;
  user_id: string;
  user_location: string;
  user_name: string;
}

export interface EngineerType{
    engineer_id: string;
    name: string;
    skillset: string;
    current_location: string;
    certifications: string;
    current_workload_minutes: string;
    email: string;
    contact: string;
    rating: string;
    energy_level: string;

}

export interface ServiceType{
      request_id: string;
                user_id: string;
                requested_service: string;
                price: string;
                location: string;
                priority: string;
                required_skill: string;
                estimated_duration_minutes: string;
                requested_datetime: string;
                scheduled_datetime: string;
                status: string;
                assigned_engineer_id: string;
                crm_ticket_id: string;
                created_at: string;
}
